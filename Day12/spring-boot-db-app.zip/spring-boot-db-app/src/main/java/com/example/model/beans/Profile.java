package com.example.model.beans;

import java.time.LocalDate;
import javax.persistence.*;
import java.util.*;

@Entity 
public class Profile {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto generates id
	private int profileId;
	private String name;
	private long phone;
	private LocalDate dob;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "profileidref")
	private List<Friend> friends;
	
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public List<Friend> getFriends() {
		return friends;
	}
	public void setFriends(List<Friend> friends) {
		this.friends = friends;
	}
	
}
