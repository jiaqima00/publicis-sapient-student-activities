package com.example.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.exceptions.ProfileNotFoundException;
import com.example.model.beans.Friend;
import com.example.model.beans.Profile;
import com.example.model.service.FriendService;
import com.example.model.service.ProfileService;

@RestController
@RequestMapping("/profile")
public class ProfileController {
	
	@Autowired
	private ProfileService profileService;
	@Autowired
	private FriendService friendService;
	
	@PostMapping
	public ResponseEntity<Object> store(Profile profile) {
		Profile storedProfile = profileService.storeProfile(profile);
		return ResponseEntity.status(HttpStatus.CREATED).body(storedProfile);
	}
	
	@GetMapping
	public ResponseEntity<Object> getProfiles() {
		List<Profile> list = profileService.fetchProfiles();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Object> getProfile(@PathVariable("id") int id) {
		try {
			Profile profile = profileService.fetchProfile(id);
			return ResponseEntity.status(HttpStatus.OK).body(profile);
		} catch(ProfileNotFoundException e) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("error", e.getMessage());
			map.put("status", "404");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
		}
	}
	
	@PostMapping("/{profileId}")
	public ResponseEntity<Object> addfFriend(@RequestBody Friend friend, @PathVariable("profileId") int id) {
		Friend createdFriend = friendService.addFriend(id, friend);
		Map<String, String> map = new HashMap<>();
		map.put("message", "Added " + createdFriend.getName());
		map.put("profileId", "Profile id: " + createdFriend.getProfileRef());
		return ResponseEntity.status(HttpStatus.OK).body(map);
	}
	
	@GetMapping("/{id}/{newNum}")
	public ResponseEntity<Object> changeNumber(@PathVariable("id") int id, @PathVariable("newNum") long num) {
		try {
			Profile profile = profileService.fetchProfile(id);
			profile.setPhone(num);
			return ResponseEntity.status(HttpStatus.OK).body(profile);
		} catch(ProfileNotFoundException e) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("error", e.getMessage());
			map.put("status", "404");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
		}
	}
	
	@DeleteMapping("/{id}/{friendId}")
	public ResponseEntity<Object> deleteFriend(@PathVariable("id") int id, @PathVariable("friendId") int friendId) {
		try {
			Profile profile = profileService.fetchProfile(id);
			List<Friend> temp = profile.getFriends();
			for(int i = 0; i < temp.size(); i++) {
				if(i == friendId) {
					temp.remove(i);
					break;
				}
			}
			profile.setFriends(temp);
			return ResponseEntity.status(HttpStatus.OK).body(profile);
		} catch(ProfileNotFoundException e) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("error", e.getMessage());
			map.put("status", "404");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
		}
	}
	
	@GetMapping("/{id}/{friendId}/{newNum}")
	public ResponseEntity<Object> changeFriendNum(@PathVariable("id") int id, @PathVariable("friendId") int friendId, @PathVariable("newNum") long num) {
		try {
			Profile profile = profileService.fetchProfile(id);
			List<Friend> temp = profile.getFriends();
			for(Friend f : temp) {
				if(f.getId() == friendId) {
					f.setPhone(num);
				}
			}
			profile.setFriends(temp);
			return ResponseEntity.status(HttpStatus.OK).body(profile);
		} catch(ProfileNotFoundException e) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("error", e.getMessage());
			map.put("status", "404");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
		}
	}
}
