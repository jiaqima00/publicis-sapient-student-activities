package com.example.model.service;

import com.example.model.beans.Friend;

public interface FriendService {
	public Friend addFriend(int profileId, Friend friend);
}
