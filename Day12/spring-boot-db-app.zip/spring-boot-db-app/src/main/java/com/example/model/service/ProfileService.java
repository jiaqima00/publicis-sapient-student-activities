package com.example.model.service;

import java.util.List;

import com.example.exceptions.ProfileNotFoundException;
import com.example.model.beans.Profile;

// Interface for the business layer, needs to be implemented by developer
public interface ProfileService {
	public Profile storeProfile(Profile profile);
	
	public List<Profile> fetchProfiles();
	
	public Profile fetchProfile(int id) throws ProfileNotFoundException;
}
